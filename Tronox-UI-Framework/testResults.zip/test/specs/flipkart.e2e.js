

describe('Flikart',async()=>{
        it('Flip kart OTP',async()=>{
            await browser.url("https://www.flipkart.com/");
            await browser.pause(3000) 

        })
})